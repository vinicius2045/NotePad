
package tranotepad;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Compiler.command;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TraNotePad  extends JFrame implements ActionListener  {

     JMenuBar barraMenu = new JMenuBar();
    JMenu arquivo = new JMenu("Arquivo");
    JMenu editar = new JMenu("Editar");
    JMenu ajuda = new JMenu ("Ajuda");
    
    JMenuItem novoArquivo = new JMenuItem("Novo");
    JMenuItem abrirArquivo = new JMenuItem("Abrir");
    JMenuItem salvarArquivo = new JMenuItem("Salvar");
    JMenuItem sair = new JMenuItem("Sair");    
    
    JMenuItem colar = new JMenuItem("Colar");
    JMenuItem copiar = new JMenuItem("Copiar");
    JMenuItem cortar = new JMenuItem("Cortar");
    JMenuItem SelecionarTudo = new JMenuItem("Selecionar Tudo");
    
    JMenuItem sobre = new JMenuItem(" Sobre ");
    
    JTextArea areaTexto = new JTextArea();
    
    
     TraNotePad() {
        setTitle("Aplicativo Bloco De Notas");
        setBounds(300, 200, 800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setJMenuBar(barraMenu);
        

        barraMenu.add(arquivo);
        barraMenu.add(editar);
        barraMenu.add(ajuda);
        
        
        arquivo.add(novoArquivo);
        arquivo.add(abrirArquivo);
        arquivo.add(salvarArquivo);
        arquivo.add(sair);
        
        editar.add(colar);
        editar.add(copiar);
        editar.add(cortar);
        editar.add(SelecionarTudo);
        
        ajuda.add(sobre);
        
        
        
        

        JScrollPane telaPrincipalRolagem = new JScrollPane(areaTexto);

        add(telaPrincipalRolagem);
        
        areaTexto.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 20));
        areaTexto.setLineWrap(true);
        areaTexto.setWrapStyleWord(true);
        
        
        novoArquivo.addActionListener(this);
        abrirArquivo.addActionListener(this);
        salvarArquivo.addActionListener(this);
        sair.addActionListener(this);
        
        copiar.addActionListener(this);
        colar.addActionListener(this);
        cortar.addActionListener(this);
        SelecionarTudo.addActionListener(this);
        
        ajuda.addActionListener(this);
        
     }
    public static void main(String[] args) {
        new TraNotePad().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
         if (e.getActionCommand().equalsIgnoreCase("Novo")) {
            areaTexto.setText(null);

        } else if (e.getActionCommand().equalsIgnoreCase("ABRIR")) {
               System.out.println("Abrir");

        } else if (e.getActionCommand().equalsIgnoreCase("Salvar")) {
               System.out.println("Salvar");

         } else if (e.getActionCommand().equalsIgnoreCase("Sair")) {
            System.exit(0);
             
        }   else if (command.equals("Sobre")) {
             ExibirDialogo();
             
        }   else if (command.equals("Cortar")) {
            cortarTexto();
            
        }   else if (command.equals("Copiar")) {
            copiarTexto();
            
        }   else if (command.equals("Colar")) {
            colarTexto();
            
        }  else if (command.equals("Selecionar Tudo")){
            selecionarTudoTexto();
        
        }

       
            
    }

    private void ExibirDialogo() {
        
    JOptionPane.showMessageDialog(TraNotePad.this, "Desenvolvido por Vinicius Vieira \n"
            + " Aplicativo De Bloco de notas Que tem\n"
            + "Algumas funções uteis",
                "Sob\"Sobre", JOptionPane.INFORMATION_MESSAGE);


    }

    private void cortarTexto() {
       areaTexto.cut();
    }

    private void copiarTexto() {
       areaTexto.copy();
    }

    private void colarTexto() {
        areaTexto.paste();

    }

    private void selecionarTudoTexto() {
        areaTexto.selectAll();
    }
    
}
